import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';

import App from './App';
import './index.css';

import { AuthProvider } from '@/app/providers/AuthProvider';
import { LanguageProvider } from '@/app/providers/LanguageProvider';
import { ProfileProvider } from '@/app/providers/ProfileProvider';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <AuthProvider>
      <ProfileProvider>
        <LanguageProvider>
          <App />
        </LanguageProvider>
      </ProfileProvider>
    </AuthProvider>
  </StrictMode>,
);
