import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router';

import { Button } from '@/components/ui/button';
import { getLanguagePair, type LanguagePair } from '@/entities/language-pair/api';
import { getLanguages, type Language } from '@/entities/language/api';
import { getTopic, type Topic } from '@/entities/topic/api';
import { getWordEntries, type WordEntry } from '@/entities/word-entry/api';

type CardDirection = 'source-to-target' | 'target-to-source';

export function CardsPage() {
  const { pairId, topicId } = useParams();

  const [topic, setTopic] = useState<Topic | null>(null);

  const [languagePair, setLanguagePair] = useState<LanguagePair | null>(null);

  const [languages, setLanguages] = useState<Language[] | null>(null);

  const [wordEntries, setWordEntries] = useState<WordEntry[] | null>(null);

  const [direction, setDirection] = useState<CardDirection>('source-to-target');

  const [currentIndex, setCurrentIndex] = useState(0);

  const [isFlipped, setIsFlipped] = useState(false);

  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!pairId || !topicId) {
      return;
    }

    const currentPairId = pairId;
    const currentTopicId = topicId;

    async function loadData() {
      try {
        const [topicData, pairData, languagesData, wordsData] = await Promise.all([
          getTopic(currentTopicId),
          getLanguagePair(currentPairId),
          getLanguages(),
          getWordEntries(currentTopicId),
        ]);

        setTopic(topicData);
        setLanguagePair(pairData);
        setLanguages(languagesData);
        setWordEntries(wordsData);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to load cards');
      }
    }

    loadData();
  }, [pairId, topicId]);

  const sourceLanguage = useMemo(() => {
    if (!languagePair || !languages) {
      return null;
    }

    return languages.find((language) => language.id === languagePair.source_language_id) ?? null;
  }, [languagePair, languages]);

  const targetLanguage = useMemo(() => {
    if (!languagePair || !languages) {
      return null;
    }

    return languages.find((language) => language.id === languagePair.target_language_id) ?? null;
  }, [languagePair, languages]);

  if (!pairId || !topicId) {
    return (
      <main className="min-h-screen bg-background p-8">
        <div className="mx-auto max-w-3xl">
          <p className="text-destructive">Cards not found.</p>
        </div>
      </main>
    );
  }

  if (error) {
    return (
      <main className="min-h-screen bg-background p-8">
        <div className="mx-auto max-w-3xl">
          <Link
            to={`/pair/${pairId}/topic/${topicId}`}
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            ← Back to topic
          </Link>

          <p className="mt-6 text-destructive">{error}</p>
        </div>
      </main>
    );
  }

  if (!topic || !languagePair || !languages || !wordEntries) {
    return (
      <main className="min-h-screen bg-background p-8">
        <div className="mx-auto max-w-3xl">
          <p>Loading...</p>
        </div>
      </main>
    );
  }

  if (wordEntries.length === 0) {
    return (
      <main className="min-h-screen bg-background p-8">
        <div className="mx-auto max-w-3xl">
          <Link
            to={`/pair/${pairId}/topic/${topicId}`}
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            ← Back to {topic.name}
          </Link>

          <div className="mt-8 rounded-xl border border-dashed p-8 text-center">
            <h1 className="text-xl font-semibold">No cards yet</h1>

            <p className="mt-2 text-sm text-muted-foreground">
              Add some words to this topic first.
            </p>
          </div>
        </div>
      </main>
    );
  }

  const cards = wordEntries;

  const currentWord = cards[currentIndex];

  const frontText =
    direction === 'source-to-target' ? currentWord.source_text : currentWord.target_text;

  const backText =
    direction === 'source-to-target' ? currentWord.target_text : currentWord.source_text;

  const frontLanguage =
    direction === 'source-to-target'
      ? (sourceLanguage?.name ?? 'Language 1')
      : (targetLanguage?.name ?? 'Language 2');

  const backLanguage =
    direction === 'source-to-target'
      ? (targetLanguage?.name ?? 'Language 2')
      : (sourceLanguage?.name ?? 'Language 1');

  function goPrevious() {
    setCurrentIndex((current) => (current === 0 ? cards.length - 1 : current - 1));

    setIsFlipped(false);
  }

  function goNext() {
    setCurrentIndex((current) => (current === cards.length - 1 ? 0 : current + 1));

    setIsFlipped(false);
  }

  function changeDirection(nextDirection: CardDirection) {
    setDirection(nextDirection);
    setIsFlipped(false);
  }

  function flipCard() {
    setIsFlipped((current) => !current);
  }

  return (
    <main className="min-h-screen bg-background p-8">
      <div className="mx-auto max-w-3xl">
        <Link
          to={`/pair/${pairId}/topic/${topicId}`}
          className="text-sm text-muted-foreground hover:text-foreground"
        >
          ← Back to {topic.name}
        </Link>

        <div className="mt-6">
          <h1 className="text-3xl font-bold tracking-tight">Cards</h1>

          <p className="mt-2 text-muted-foreground">{topic.name}</p>
        </div>

        <div className="mt-6 flex flex-wrap gap-2">
          <Button
            type="button"
            variant={direction === 'source-to-target' ? 'default' : 'outline'}
            onClick={() => changeDirection('source-to-target')}
          >
            {sourceLanguage?.name ?? 'Language 1'}
            {' → '}
            {targetLanguage?.name ?? 'Language 2'}
          </Button>

          <Button
            type="button"
            variant={direction === 'target-to-source' ? 'default' : 'outline'}
            onClick={() => changeDirection('target-to-source')}
          >
            {targetLanguage?.name ?? 'Language 2'}
            {' → '}
            {sourceLanguage?.name ?? 'Language 1'}
          </Button>
        </div>

        <p className="mt-6 text-center text-sm text-muted-foreground">
          Card {currentIndex + 1} of {cards.length}
        </p>

        <button
          type="button"
          onClick={flipCard}
          className="mt-4 flex min-h-80 w-full cursor-pointer flex-col items-center justify-center rounded-2xl border bg-card p-8 text-center shadow-sm transition hover:shadow-md"
        >
          {!isFlipped ? (
            <>
              <p className="text-sm text-muted-foreground">{frontLanguage}</p>

              <p className="mt-4 break-words text-4xl font-semibold">{frontText}</p>

              <p className="mt-8 text-sm text-muted-foreground">Click to reveal</p>
            </>
          ) : (
            <>
              <p className="text-sm text-muted-foreground">{backLanguage}</p>

              <p className="mt-4 break-words text-4xl font-semibold">{backText}</p>

              {currentWord.meaning && (
                <div className="mt-8 w-full border-t pt-6">
                  <p className="text-xs uppercase tracking-wide text-muted-foreground">Meaning</p>

                  <p className="mt-2 break-words text-base">{currentWord.meaning}</p>
                </div>
              )}

              <p className="mt-8 text-sm text-muted-foreground">Click to flip back</p>
            </>
          )}
        </button>

        <div className="mt-6 flex items-center justify-between gap-4">
          <Button type="button" variant="outline" onClick={goPrevious}>
            ← Previous
          </Button>

          <Button type="button" onClick={flipCard}>
            Flip
          </Button>

          <Button type="button" variant="outline" onClick={goNext}>
            Next →
          </Button>
        </div>
      </div>
    </main>
  );
}
